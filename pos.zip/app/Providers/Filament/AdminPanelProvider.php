<?php

namespace App\Providers\Filament;

use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Widgets;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use BezhanSalleh\FilamentShield\FilamentShieldPlugin;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\View;
use Filament\Support\Assets\Css;
use Filament\Support\Facades\FilamentAsset;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->favicon(asset('images/fav-icon.png'))
            ->plugins([
                     FilamentShieldPlugin::make(), // <-- Tambahkan baris ini
            ])
            ->colors([
                'primary' => Color::Sky,
            ])
            ->topNavigation()
            ->brandName('Kasir Kita')
           ->brandLogo(function () {
                $user = auth()->user();

                // Ambil data tenant jika user terhubung ke tenant
                $brandName = $user?->tenant_id && $user->tenant 
                    ? $user->tenant->nama 
                    : 'Pusat Control';

                // Ambil URL logo tenant atau default
                $logoUrl = asset('images/kasir kita-warna.png');

                return View::make('filament.components.brand-header', [
                    'logoUrl' => $logoUrl,
                    'brandName' => $brandName,
                    'appName' => config('app.name', 'Kasir Kita'), // Nama Aplikasi
                ]);
            })
            // Sesuaikan tinggi brand area
            ->brandLogoHeight('6rem')
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\\Filament\\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\\Filament\\Pages')
            ->pages([
                Pages\Dashboard::class,
               \App\Filament\Pages\Dashboard::class,
            ])
            // ->viteTheme('resources/css/filament/admin/theme.css')
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\\Filament\\Widgets')
            ->widgets([
                // Widgets\AccountWidget::class,
                // Widgets\FilamentInfoWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }

    public function boot(): void
{
    FilamentAsset::register([
        Css::make('custom-stylesheet', resource_path('css/filament/admin/theme.css')),
    ]);
}
}
